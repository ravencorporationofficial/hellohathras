# Design System Document: Hathras District Digital Interface

## 1. Overview & Creative North Star
**Creative North Star: The Civic Monolith**
This design system moves away from the cluttered, "table-heavy" legacy of traditional e-governance. Instead, it adopts the persona of a *Civic Monolith*: a digital experience that feels as stable as stone yet as clear as glass. We reject the "standard government template" in favor of high-end editorial layouts characterized by bold typographic scales, intentional asymmetry, and deep, tonal layering.

By using **Public Sans** and a sophisticated palette of deep Navys (`primary`) and clean architectural whites (`surface`), we ensure that trust is earned through precision, not just through a logo. The experience is designed to feel authoritative, accessible, and premium—elevating the status of the Hathras District administration.

---

## 2. Colors
Our palette is rooted in the deep blues of the National Informatics Centre, reimagined through a modern Material 3 lens to provide depth and soul.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections or containers. Separation must be achieved through background shifts. For example, a `surface-container-low` section should sit directly against a `surface` background. Let the change in value define the edge.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of paper and glass.
*   **Base:** `surface` (#f9f9ff) – The canvas.
*   **Secondary Content Areas:** `surface-container-low` (#f3f3fa).
*   **Elevated Components (Cards):** `surface-container-lowest` (#ffffff).
*   **Nesting Logic:** Place a white card (`surface-container-lowest`) inside a light blue-grey section (`surface-container-low`) to create natural definition without a single line of ink.

### Signature Textures: Glass & Gradient
To prevent the app from feeling "flat," use the following:
*   **The Civic Gradient:** For primary CTAs and Hero headers, use a linear gradient from `primary` (#000042) to `primary-container` (#020381). This adds a "weighted" feel that solid hex codes lack.
*   **Glassmorphism:** Use semi-transparent `surface` colors with a 20px backdrop-blur for floating navigation bars or sticky headers. This integrates the UI into the content rather than boxing it in.

---

## 3. Typography
We utilize **Public Sans** for its neutral, yet strong architectural quality. It performs exceptionally well in both English and Hindi scripts, maintaining legibility at small scales.

*   **Display (Large/Medium):** Reserved for "Hero" moments—district statistics or major announcements. The tight tracking and large scale convey modern authority.
*   **Headline (Small):** Use for page titles. Bold weight, `primary` color.
*   **Title (Medium/Small):** Used for card headings. This is the "Entry Point" for the user's eye.
*   **Body (Large/Medium):** Optimized for high-density information like government orders or directory details.
*   **Labels:** Always uppercase with slightly increased letter spacing for a "metadata" feel.

---

## 4. Elevation & Depth
In this system, depth is a function of light and color, not shadows and lines.

*   **Tonal Layering:** Use the `surface-container` tiers (Lowest to Highest) to "stack" importance. High-priority information lives on `surface-container-lowest` (pure white) for maximum contrast against the background.
*   **Ambient Shadows:** If a card must "float" (e.g., a critical alert or action sheet), use a shadow with a blur of 32px and an opacity of 6%. Use a tint of `on-surface` (#191c21) for the shadow color to ensure it looks like a natural environmental occlusion.
*   **The Ghost Border:** For accessibility in form fields, use the `outline-variant` token at **15% opacity**. It should be felt, not seen.
*   **Tri-Color Accents:** Use `tertiary` (deep green) and `on-tertiary-container` (saffron-adjacent tones) sparingly for status indicators (Success/Pending) to subtly nod to the national identity without overwhelming the professional blue/white core.

---

## 5. Components

### Buttons
*   **Primary:** High-contrast `primary` to `primary-container` gradient. Roundedness: `md` (0.375rem) for a sturdy, professional feel.
*   **Secondary:** Ghost style with a `surface-variant` background. No border.
*   **Tertiary:** Text-only in `primary` weight, used for low-priority actions like "Learn More."

### Cards & Directories
*   **Rule:** Forbid divider lines.
*   **Structure:** Use a `surface-container-lowest` card. Use `spacing-6` (1.5rem) to separate internal elements. Group related directory info using vertical white space and `label-md` headers in `on-surface-variant`.

### Input Fields
*   **Style:** Minimalist. `surface-container-high` background with a `Ghost Border` on focus. Labels should be `label-md` and always visible (no floating labels that disappear).

### Interactive Chips
*   **Filter Chips:** Use `secondary-container` with `on-secondary-container` text. Use `full` (9999px) roundedness to distinguish them from the more "rigid" informational cards.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical layouts for the home screen (e.g., a large headline on the left with a smaller supporting CTA on the right).
*   **Do** use high-contrast typography (`display-lg`) to highlight Hathras’s unique heritage or statistics.
*   **Do** ensure Hindi and English text are given equal visual weight and padding.

### Don't
*   **Don't** use 1px borders to separate list items. Use a `surface-container-low` background shift instead.
*   **Don't** use pure black (#000000) for text. Use `on-surface` (#191c21) to maintain a premium, ink-on-paper feel.
*   **Don't** use standard "drop shadows." If it doesn't look like ambient light, don't use it.
*   **Don't** clutter the screen. If a piece of information isn't vital, use the `Spacing Scale` (16 or 20) to push it away and give the user room to breathe.